<?php

namespace App\Http\Livewire\Institucional;

use Livewire\Component;

class SlideReservasAtivas extends Component
{
    public function render()
    {
        return view('livewire.institucional.slide-reservas-ativas');
    }
}
