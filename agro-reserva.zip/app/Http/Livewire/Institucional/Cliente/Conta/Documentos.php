<?php

namespace App\Http\Livewire\Institucional\Cliente\Conta;

use Livewire\Component;
use App\Models\ClienteDocumento;

class Documentos extends Component
{
    public function getDocumentosByTipo($tipo){
        $documentos = ClienteDocumento::where('cliente_id', session()->get('cliente')['id'])->where('tipo', $tipo)->get();
        return $documentos;
    }
    public function render()
    {
        return view('livewire.institucional.cliente.conta.documentos');
    }
}
