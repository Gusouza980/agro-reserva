<?php

namespace App\Http\Livewire\Institucional\Cliente\Conta;

use Livewire\Component;

class Pagina extends Component
{
    public $cliente;

    public function moun($cliente){
        $this->cliente = $cliente;
    }
    
    public function render()
    {
        return view('livewire.institucional.cliente.conta.pagina');
    }
}
