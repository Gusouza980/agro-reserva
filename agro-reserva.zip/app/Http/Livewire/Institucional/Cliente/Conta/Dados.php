<?php

namespace App\Http\Livewire\Institucional\Cliente\Conta;

use App\Models\Cliente;
use Livewire\Component;

class Dados extends Component
{
    public $cliente = [];

    public function updated($propertyName){
    }

    public function hasConjugue(){
        if(isset($this->cliente['estado_civil']) && $this->cliente['estado_civil'] >= 3){
            return true;
        }else{
            return false;
        }
    }

    public function salvar(){
        Cliente::find($this->cliente['id'])->update($this->cliente);
        $this->dispatchBrowserEvent('notificaToastr', ['tipo' => 'success', 'mensagem' => 'Dados salvos com sucesso!']);
    }

    public function mount(){
        $this->cliente = Cliente::findOrFail(session()->get("cliente")['id'])->toArray();
    }

    public function render()
    {
        return view('livewire.institucional.cliente.conta.dados');
    }
}
