<?php

namespace App\Http\Livewire\Sistema\Banners;

use Livewire\Component;

class ModalExclusao extends Component
{
    public function render()
    {
        return view('livewire.sistema.banners.modal-exclusao');
    }
}
