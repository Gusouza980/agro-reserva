<?php

namespace App\Classes\Funcoes;

class Usuarios
{
    public function __construct(){

    }
    
}
