<?php

    return [
        'png' => 'fas fa-file-image',
        'jpg' => 'fas fa-file-image',
        'jpeg' => 'fas fa-file-image',
        'webp' => 'fas fa-file-image',
        'gif' => 'fas fa-file-image',
        'svg' => 'fas fa-file-image',

        'pdf' => 'fas fa-file-pdf',
        'docx' => 'fas fa-file-word',
        'csv' => 'fas fa-file-csv',
        'xlxs' => 'fas fa-file-excel',

        'mp3' => 'fas fa-file-audio',
        'wav' => 'fas fa-file-audio',
        'wma' => 'fas fa-file-audio',

        'mp4' => 'fas fa-file-video',
        'mov' => 'fas fa-file-video',
        'wmv' => 'fas fa-file-video',
        'avi' => 'fas fa-file-video',
        'mkv' => 'fas fa-file-video'
    ];

?>