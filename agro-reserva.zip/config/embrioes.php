<?php

return [
    "tipos" => [
        0 => "Embrião",
        1 => "Sêmen"
    ],
    "categorias" => [
        0 => "Standard",
        1 => "Premium",
    ],

]

?>