<?php

    return [
        1 => "Pré Cadastro",
        2 => "Dados Pessoais",
        3 => "Dados da Propriedade",
        4 => "Informações Complementares",
        5 => "Verificação de Documento"
    ]

?>