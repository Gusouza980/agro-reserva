<?php

return [
    'segmentos' => [
        0 => "Sêmen",
        1 => "Roupas",
    ],
];

?>