require('./bootstrap');

import intlTelInput from 'intl-tel-input';

window.intlTelInput = intlTelInput;