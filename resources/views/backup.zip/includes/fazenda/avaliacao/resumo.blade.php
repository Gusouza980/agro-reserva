<div class="row py-4 justify-content-center justify-content-lg-start">
    <div class="col-12 px-0 text-section2-fazenda text-justify">
        <span>{{$fazenda->texto_conheca_avaliacao_resumo}}</span>
    </div>
</div>